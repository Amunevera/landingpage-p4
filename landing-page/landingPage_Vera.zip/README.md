# Landing Page Project
This project is about creating a landing page by manipulating DOM and writing a function that allows a section to scroll to view when selected from the menu.

## Author's name
Enevara, Vera Amune

### Table of Contents 
convert project from a static project to an interactive one. 
modifying the HTML and CSS files.

#### Instructions
load the landing page
select any of the section
notice how the page scrolls to the section selected
notice how swift the process is.

##### Credits
Mr. Ademola Akinpelu. (frontend Classroom session head)
Udacity,
Edoworx Initiative, Edo State, Nigeria,
God Almighty.